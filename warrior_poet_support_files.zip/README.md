# The Writings of a Warrior Poet

A long-scroll HTML site that houses the raw poetry and reflections of a combat veteran.  
Themes include PTSD, healing, fatherhood, and the silent war after the war.

Built for permanence. Written for those still walking home.

Live Site: [https://zulufoxtrot-delta.github.io/warriorpoet.github.io/](https://zulufoxtrot-delta.github.io/warriorpoet.github.io/)
